<?php
header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=data-kasbon-" . date('Y-m-d') . ".xls");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: private", false);

$servername = "localhost";
$username = "root";
$password = "admin2023";
$dbname = "db_toko";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$exportRange = isset($_GET['export_range']) ? $_GET['export_range'] : '';

$dateFilter = '';
switch ($exportRange) {
    case '1_week':
        $dateFilter = "AND date_time >= DATE_SUB(CURDATE(), INTERVAL 1 WEEK)";
        break;
    case '1_month':
        $dateFilter = "AND date_time >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)";
        break;
    case '2_months':
        $dateFilter = "AND date_time >= DATE_SUB(CURDATE(), INTERVAL 2 MONTH)";
        break;
    case '3_months':
        $dateFilter = "AND date_time >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)";
        break;
    case '1_year':
        $dateFilter = "AND date_time >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)";
        break;
}

$sql = "SELECT id_bayar_hutang, nominal_bayar, kasbon, date_time, status_kasbon FROM bayar_hutang WHERE 1=1 " . $dateFilter;
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr>";
    echo "<th>ID Bayar Hutang</th>";
    echo "<th>Nominal Bayar</th>";
    echo "<th>Kasbon</th>";
    echo "<th>Date Time</th>";
    echo "<th>Status Kasbon</th>";
    echo "</tr>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id_bayar_hutang'] . "</td>";
        echo "<td>" . $row['nominal_bayar'] . "</td>";
        echo "<td>" . $row['kasbon'] . "</td>";
        echo "<td>" . $row['date_time'] . "</td>";
        echo "<td>" . $row['status_kasbon'] . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "No data found.";
}

$conn->close();
?>