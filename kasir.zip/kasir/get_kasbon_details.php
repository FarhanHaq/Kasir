<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "admin2023";
$dbname = "db_toko";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$kasbon = $_GET['kasbon'];

// Debug output
error_log("Received kasbon: " . $kasbon);

// Tambahkan status_kasbon ke query
$sql = "SELECT n.id_nota, n.id_barang, b.nama_barang, b.harga_beli, b.harga_jual, n.total, n.tanggal_input, m.nm_member, n.status_kasbon
        FROM nota n 
        INNER JOIN barang b ON n.id_barang = b.id_barang 
        INNER JOIN member m ON n.id_member = m.id_member 
        WHERE n.kasbon = ?";

// Debug output
error_log("Executing SQL: " . $sql);

$stmt = $conn->prepare($sql);

// Cek jika prepare() berhasil
if ($stmt === false) {
    error_log("Prepare failed: " . $conn->error);
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param('s', $kasbon);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $no = 1;
    while ($row = $result->fetch_assoc()) {
        // Tentukan teks tombol berdasarkan status_kasbon
        $buttonText = $row["status_kasbon"] == 1 ? "Sudah Dibayar" : "Lunas";
        $buttonClass = $row["status_kasbon"] == 1 ? "btn-secondary" : "btn-success";

        echo "<tr>";
        echo "<td>" . $no . "</td>";
        echo "<td>" . $row["id_barang"] . "</td>";
        echo "<td>" . $row["nama_barang"] . "</td>";
        echo "<td>" . $row["harga_beli"] . "</td>";
        echo "<td>" . $row["harga_jual"] . "</td>";
        echo "<td>" . $row["total"] . "</td>";
        echo "<td>" . $row["nm_member"] . "</td>";
        echo "<td>" . $row["tanggal_input"] . "</td>";
        echo "<td><button class='btn $buttonClass' onclick=\"markAsPaid(" . $row["id_nota"] . ", '" . $kasbon . "')\">$buttonText</button></td>";
        echo "</tr>";
        $no++;
    }
} else {
    // Debug output
    error_log("No data found for kasbon: " . $kasbon);
    echo "<tr><td colspan='9'>No data found</td></tr>";
}

$stmt->close();
$conn->close();
?>