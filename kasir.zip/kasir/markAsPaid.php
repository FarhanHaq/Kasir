<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "admin2023";
$dbname = "db_toko";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id_nota = $_POST['id_nota'];
$kasbon = $_POST['kasbon'];
$tanggal = date('Y-m-d H:i:s');
$periode = date('m-Y');

// Update status kasbon
$sql = "UPDATE nota SET status_kasbon = 1, tanggal_input = ?, periode = ? WHERE id_nota = ? AND kasbon = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ssis', $tanggal, $periode, $id_nota, $kasbon);

if ($stmt->execute()) {
    echo "Success";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>