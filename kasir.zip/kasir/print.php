<?php 
    require 'config.php';
    include $view;
    $lihat = new view($config);
    $toko = $lihat -> toko();
    $hsl = $lihat -> penjualan();
?>
<html>
<head>
    <title>Print</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            width: 58mm; /* Sesuaikan dengan lebar kertas thermal printer */
        }
        .container {
            padding: 10px;
        }
        .table {
            width: 100%;
            margin-bottom: 10px;
            font-size: 10px;
        }
        .pull-right {
            float: right;
            font-size: 10px;
            text-align: right;
            width: 100%; /* Atur lebar agar rapi di kertas thermal */
        }
        p {
            margin: 5px 0;
            line-height: 1.0;
        }
        hr {
            margin: 5px 0;
        }
        .with-border-bottom td {
            border-bottom: 1px solid #000;
        }
    </style>
</head>
<body>
    <script>window.print();</script>
    <div class="container">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <center>
                    <p><?php echo $toko['nama_toko']; ?></p>
                    <hr>
                    <p><?php echo $toko['alamat_toko']; ?></p>
                    <hr>
                    <p>Tanggal : <?php echo date("j F Y, G:i:s");?></p>
                    <p>Nomor : 
                        <?php 
                            $tahun = date("y");
                            $bulan = date("m");
                            $tanggal = date("d");
                            $jam = date("H");
                            $menit = date("i");
                            $nomor = "SER" . $tahun . $bulan . $tanggal . $jam . $menit;
                            echo $nomor;
                        ?>
                    </p>
                    <hr>
                </center>
                <table class="table table-bordered">
                    <tr>
                        <td>Nama Barang</td>
                    </tr>
                    <tr class="with-border-bottom">
                        <td>QTY</td>
                        <td>H SATUAN</td>
                        <td>TOTAL</td>
                    </tr>
                    <?php $no=1; foreach($hsl as $isi){?>
                    <tr>
                        <td colspan='3'>
                            <?php 
                                $nama_barang = $isi['nama_barang'];
                                if (strlen($nama_barang) > 27) {
                                    echo substr($nama_barang, 0, 27) . "...";
                                } else {
                                    echo $nama_barang;
                                }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td><center><?php echo $isi['jumlah'];?></center></td>
                        <td><?php echo "Rp. " . number_format($isi['harga_satuan'], 0, ',', '.'); ?></td>
                        <td><?php echo "Rp. " . number_format($isi['total'], 0, ',', '.'); ?></td>
                    </tr>
                    <?php $no++; }?>
                </table>
                <hr>
                <div class="pull-right">
                    <?php $hasil = $lihat -> jumlah(); ?>
                    Total : Rp.<?php echo number_format($hasil['bayar']);?>,-
                    <br/>
                    Bayar : Rp.<?php echo number_format($_GET['bayar']);?>,-
                    <br/>
                    Kembali : Rp.<?php echo number_format($_GET['kembali']);?>,-
                </div>
                <div class="clearfix"></div>
                <center>
                    <p></p>
                    <p>Terima Kasih Telah berbelanja di toko kami !</p>
                </center>
            </div>
            <div class="col-sm-4"></div>
        </div>
    </div>
</body>
</html>