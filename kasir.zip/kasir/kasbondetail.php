<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "admin2023";
$dbname = "db_toko";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$kasbon = $_GET['kasbon'];

// Query untuk mengambil data kasbon yang unik
$sql = "SELECT n.id_nota, n.id_barang, b.nama_barang, b.harga_beli, b.harga_jual, n.total, n.tanggal_input, m.nm_member, n.status_kasbon
        FROM nota n 
        INNER JOIN barang b ON n.id_barang = b.id_barang 
        INNER JOIN member m ON n.id_member = m.id_member 
        WHERE n.kasbon = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $kasbon);
$stmt->execute();
$result = $stmt->get_result();

$total_hutang = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $total_hutang += $row["harga_jual"];
    }
}

// Query untuk mengambil total pembayaran dari tabel bayar_hutang
$payment_sql = "SELECT SUM(nominal_bayar) AS total_bayar FROM bayar_hutang WHERE kasbon = ?";
$payment_stmt = $conn->prepare($payment_sql);
$payment_stmt->bind_param("s", $kasbon);
$payment_stmt->execute();
$payment_result = $payment_stmt->get_result();
$total_bayar_row = $payment_result->fetch_assoc();
$total_bayar = isset($total_bayar_row['total_bayar']) ? $total_bayar_row['total_bayar'] : 0;

$sisa_hutang = $total_hutang - $total_bayar;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nominal_bayar = $_POST['nominal_bayar'];

    // Query untuk menyimpan data ke tabel bayar_hutang
    $insert_sql = "INSERT INTO bayar_hutang (nominal_bayar, kasbon, status_kasbon) VALUES (?, ?, 0)";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("is", $nominal_bayar, $kasbon);
    
    if ($insert_stmt->execute()) {
        echo "Pembayaran berhasil disimpan.";
        // Refresh page to update the remaining debt
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit();
    } else {
        echo "Terjadi kesalahan: " . $conn->error;
    }

    $insert_stmt->close();
}

// Query untuk mengambil riwayat pembayaran
$history_sql = "SELECT nominal_bayar, status_kasbon,date_time FROM bayar_hutang WHERE kasbon = ?";
$history_stmt = $conn->prepare($history_sql);
$history_stmt->bind_param("s", $kasbon);
$history_stmt->execute();
$history_result = $history_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kasbon Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
       body {
        background: url('Background2.jpg') no-repeat center center fixed;
        background-size: cover;
        color: #fff;
      }
        .container {
            margin-top: 50px;
        }
        .table {
            margin-top: 20px;
        }
        .table th, .table td {
            text-align: center;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
        }
        h5{
            color:black;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="back-button">
        <a href="kasbon.php" class="btn btn-secondary">BACK</a>
    </div>
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h3 class="card-title">Data Kasbon Dashboard</h3>
        </div>
        <div class="card-body">
            <h5>Kasbon: <?= ($kasbon) ?></h5>
            <?php if ($sisa_hutang == 0): ?>
                <h5 class="lunas" style="color:green;">Lunas</h5>
            <?php else: ?>
                <h5>Total Hutang: Rp. <?= number_format($sisa_hutang, 0, ',', '.') ?></h5>
            <?php endif; ?>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        $no = 1;
                        // Reset result pointer to beginning
                        $result->data_seek(0);
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $no . "</td>";
                            echo "<td>" . $row["nama_barang"] . "</td>";
                            echo "<td>" . number_format($row["harga_jual"], 0, ',', '.') . "</td>";
                            echo "</tr>";
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='3'>No data found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <form method="post" action="">
                <div class="form-group">
                    <label for="nominal_bayar" style="color:black;">Yang Akan Dibayarkan :</label>
                    <input type="number" class="form-control" id="nominal_bayar" name="nominal_bayar" required>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>

    <?php if ($history_result->num_rows > 0): ?>
    <div class="card mt-4">
        <div class="card-header bg-danger text-white">
            <h3 class="card-title">Riwayat Pembayaran</h3>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nominal Bayar</th>
                        <th>Tanggal Bayar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    while ($history_row = $history_result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $no . "</td>";
                        echo "<td>Rp. " . number_format($history_row["nominal_bayar"], 0, ',', '.') . "</td>";
                        echo "<td>" . ($history_row["date_time"]) . "</td>";
                        // echo "<td>" . ($history_row["status_kasbon"] == 0 ? "Belum Lunas" : "Lunas") . "</td>";
                        echo "</tr>";
                        $no++;
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Bootstrap JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
$stmt->close();
$payment_stmt->close();
$history_stmt->close();
$conn->close();
?>