<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "admin2023";
$dbname = "db_toko";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mengatur jumlah baris per halaman
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Mengambil filter tanggal dari query string
$startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Mengonversi tanggal ke format yang sesuai jika ada filter
if ($startDate && $endDate) {
    $startDateFormatted = date('d-m-Y', strtotime($startDate));
    $endDateFormatted = date('d-m-Y', strtotime($endDate));
    $dateFilter = " AND SUBSTRING_INDEX(tanggal_input, ',', 1) BETWEEN '$startDateFormatted' AND '$endDateFormatted'";
} else {
    $dateFilter = '';
}

// Query untuk menghitung total data kasbon yang unik dengan filter tanggal
$sqlCount = "SELECT COUNT(DISTINCT kasbon) AS total FROM nota WHERE kasbon != ''" . $dateFilter;
$resultCount = $conn->query($sqlCount);
$totalKasbon = $resultCount->fetch_assoc()['total'];
$totalPages = ceil($totalKasbon / $limit);

// Query untuk mengambil data kasbon yang unik dengan pagination dan filter tanggal
$sql = "SELECT DISTINCT kasbon,tanggal_input FROM nota WHERE kasbon != ''" . $dateFilter . " LIMIT $start, $limit";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kasbon Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="newjs/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
        background: url('Background2.jpg') no-repeat center center fixed;
        background-size: cover;
        color: #fff;
      }
        .container {
            margin-top: 50px;
        }
        .table {
            margin-top: 20px;
        }
        .table th, .table td {
            text-align: center;
        }
        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
        }
        .pagination {
            justify-content: center;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="back-button">
        <a href="index.php" class="btn btn-primary">BACK</a>
    </div>
    <div class="card">
        <div class="card-header bg-primary text-white">
            <h3 class="card-title">Data Kasbon Dashboard</h3>
        </div>
        <div class="card-body">
            <form method="get" class="form-inline mb-3">
                <label for="start_date" class="mr-2">Start Date</label>
                <input type="date" name="start_date" id="start_date" class="form-control mr-2" value="<?php echo isset($_GET['start_date']) ? $_GET['start_date'] : ''; ?>">
                <label for="end_date" class="mr-2">End Date</label>
                <input type="date" name="end_date" id="end_date" class="form-control mr-2" value="<?php echo isset($_GET['end_date']) ? $_GET['end_date'] : ''; ?>">
                <label for="limit" class="mr-2">Show</label>
                <select name="limit" id="limit" class="form-control mr-2" onchange="this.form.submit()">
                    <option value="10" <?php if($limit == 10) echo 'selected'; ?>>10</option>
                    <option value="25" <?php if($limit == 25) echo 'selected'; ?>>25</option>
                    <option value="50" <?php if($limit == 50) echo 'selected'; ?>>50</option>
                    <option value="100" <?php if($limit == 100) echo 'selected'; ?>>100</option>
                </select>
                <label for="limit">entries</label>
                <button type="submit" class="btn btn-primary ml-2">Filter</button>
                <a href="?"><button type="button" class="btn btn-primary ml-2">Reset</button></a>
            </form>

            <form method="get" action="export_excel.php" class="form-inline mb-3">
    <label for="export_range" class="mr-2">Export</label>
    <select name="export_range" id="export_range" class="form-control mr-2">
        <option value="1_week">1 Minggu Terakhir</option>
        <option value="1_month">1 Bulan Terakhir</option>
        <option value="2_months">2 Bulan Terakhir</option>
        <option value="3_months">3 Bulan Terakhir</option>
        <option value="1_year">1 Tahun Terakhir</option>
    </select>
    <button type="submit" class="btn btn-success ml-2">Export Excel</button>
</form>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Kasbon</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        $no = $start + 1;
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $no . "</td>";
                            echo "<td>" . $row["tanggal_input"] . "</td>";
                            echo "<td>" . $row["kasbon"] . "</td>";
                            echo "<td><button class='btn btn-info' onclick=\"window.location.href='kasbondetail.php?kasbon=" . $row['kasbon'] . "'\">Detail</button></td>";
                            echo "</tr>";
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='3'>No data found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            <nav>
                <ul class="pagination">
                    <?php
                    for ($i = 1; $i <= $totalPages; $i++) {
                        echo "<li class='page-item " . ($i == $page ? 'active' : '') . "'>
                                <a class='page-link' href='?limit=$limit&page=$i'>$i</a>
                              </li>";
                    }
                    ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<!-- Bootstrap JS, Popper.js, and jQuery -->
<script src="newjs/jquery-3.5.1.min.js"></script>
<script src="newjs/popper.min.js"></script>
<script src="newjs/bootstrap.min.js"></script>

</body>
</html>

<?php
$conn->close();
?>